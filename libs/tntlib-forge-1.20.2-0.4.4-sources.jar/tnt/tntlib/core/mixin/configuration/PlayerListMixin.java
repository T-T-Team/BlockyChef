package tnt.tntlib.core.mixin.configuration;

import net.minecraft.network.Connection;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.players.PlayerList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import tnt.tntlib.api.module.configuration.config.ConfigHolder;
import tnt.tntlib.core.network.TNTNetworkManager;
import tnt.tntlib.core.network.message.S2C_CFG_SendConfigData;

import java.util.Set;

@Mixin(PlayerList.class)
public abstract class PlayerListMixin {

    @Inject(method = "placeNewPlayer", at = @At("TAIL"))
    private void configuration_sendServerConfigs(Connection connection, ServerPlayer player, CommonListenerCookie cookie, CallbackInfo ci) {
        Set<String> set = ConfigHolder.getSynchronizedConfigs();
        set.forEach(id -> TNTNetworkManager.NETWORK.sendToClient(player, new S2C_CFG_SendConfigData(id)));
    }
}
