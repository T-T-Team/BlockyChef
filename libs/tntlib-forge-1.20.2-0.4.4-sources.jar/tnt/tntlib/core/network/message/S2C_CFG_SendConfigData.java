package tnt.tntlib.core.network.message;

import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.event.network.CustomPayloadEvent;
import tnt.tntlib.TNTLib;
import tnt.tntlib.api.module.configuration.Configuration;
import tnt.tntlib.api.module.configuration.config.ConfigHolder;
import tnt.tntlib.api.module.configuration.config.adapter.TypeAdapter;
import tnt.tntlib.api.module.configuration.config.value.ConfigValue;
import tnt.tntlib.api.network.Network;
import tnt.tntlib.api.network.message.Server2ClientMessage;

import java.util.Map;

@Network.Message(TNTLib.MOD_ID)
public class S2C_CFG_SendConfigData extends Server2ClientMessage {

    private final String config;

    public S2C_CFG_SendConfigData(String config) {
        this.config = config;
    }

    public S2C_CFG_SendConfigData(FriendlyByteBuf buffer) {
        String config = buffer.readUtf();
        int i = buffer.readInt();
        ConfigHolder.getConfig(config).ifPresent(data -> {
            Map<String, ConfigValue<?>> serialized = data.getNetworkSerializedFields();
            for (int j = 0; j < i; j++) {
                String fieldId = buffer.readUtf();
                ConfigValue<?> value = serialized.get(fieldId);
                if (value == null) {
                    Configuration.LOGGER.fatal(Configuration.MAIN_MARKER, "Received unknown config value " + fieldId);
                    throw new RuntimeException("Unknown config field: " + fieldId);
                }
                setValue(value, buffer);
            }
        });
        this.config = config;
    }

    @Override
    public void encode(FriendlyByteBuf buffer) {
        buffer.writeUtf(this.config);
        ConfigHolder.getConfig(this.config).ifPresent(data -> {
            Map<String, ConfigValue<?>> serialized = data.getNetworkSerializedFields();
            buffer.writeInt(serialized.size());
            for (Map.Entry<String, ConfigValue<?>> entry : serialized.entrySet()) {
                String id = entry.getKey();
                ConfigValue<?> value = entry.getValue();
                TypeAdapter adapter = value.getAdapter();
                buffer.writeUtf(id);
                adapter.encodeToBuffer(value, buffer);
            }
        });
    }

    @Override
    public void handle(Minecraft minecraft, CustomPayloadEvent.Context context) {
    }

    @SuppressWarnings("unchecked")
    private <V> void setValue(ConfigValue<V> value, FriendlyByteBuf buffer) {
        TypeAdapter adapter = value.getAdapter();
        V v = (V) adapter.decodeFromBuffer(value, buffer);
        value.set(v);
    }
}
