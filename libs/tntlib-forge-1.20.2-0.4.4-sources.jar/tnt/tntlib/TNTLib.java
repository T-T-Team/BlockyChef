package tnt.tntlib;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import tnt.tntlib.api.module.Module;
import tnt.tntlib.api.module.ModuleManager;
import tnt.tntlib.api.module.configuration.Configuration;
import tnt.tntlib.core.network.manager.AutomaticNetworkManager;

@Mod(TNTLib.MOD_ID)
public final class TNTLib {

    public static final String MOD_ID = "tntlib";
    public static final Logger LOG = LogManager.getLogger("TNTLib");

    public TNTLib() {
        registerModules();
        ModuleManager.getInstance().accept(Module::construct);

        IEventBus eventBus = FMLJavaModLoadingContext.get().getModEventBus();
        eventBus.addListener(this::init);
    }

    public void init(FMLCommonSetupEvent event) {
        AutomaticNetworkManager.init();
    }

    private void registerModules() {
        ModuleManager manager = ModuleManager.getInstance();
        manager.register(new Configuration());
    }
}
