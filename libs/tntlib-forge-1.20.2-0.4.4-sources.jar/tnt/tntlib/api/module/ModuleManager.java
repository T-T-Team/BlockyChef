package tnt.tntlib.api.module;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public final class ModuleManager {

    private static final ModuleManager MANAGER = new ModuleManager();
    private final List<Module> moduleList = new ArrayList<>();

    public static ModuleManager getInstance() {
        return MANAGER;
    }

    public void register(Module module) {
        moduleList.add(module);
    }

    public void accept(Consumer<Module> action) {
        moduleList.forEach(action);
    }
}
