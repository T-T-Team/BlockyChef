package tnt.tntlib.api.module;

public interface Module {

    void construct();
}
