package tnt.tntlib.api.module.configuration.config.format;

public interface IConfigFormatHandler {

    IConfigFormat createFormat();

    String fileExt();
}
