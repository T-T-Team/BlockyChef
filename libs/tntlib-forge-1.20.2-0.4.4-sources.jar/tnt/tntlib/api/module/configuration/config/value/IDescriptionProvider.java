package tnt.tntlib.api.module.configuration.config.value;

public interface IDescriptionProvider {

    String[] getDescription();
}
