package tnt.tntlib.api.module.configuration.config.value;

public interface ArrayValue {

    boolean isFixedSize();

    default String elementToString(Object element) {
        return element.toString();
    }
}
