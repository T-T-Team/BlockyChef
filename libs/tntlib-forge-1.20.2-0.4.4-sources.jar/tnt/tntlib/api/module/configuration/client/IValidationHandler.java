package tnt.tntlib.api.module.configuration.client;

import tnt.tntlib.api.module.configuration.config.validate.ValidationResult;

public interface IValidationHandler {

    void setValidationResult(ValidationResult result);

    default void setOkStatus() {
        this.setValidationResult(ValidationResult.ok());
    }
}
